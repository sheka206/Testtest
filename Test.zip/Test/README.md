Fügen sie zunächst im **Head des HTML Dokuments** vor dem ``<meta>``-Tag folgendes Fragment ein:

```HTML
    <!-- Leaflet CSS and JavaScript (in this order) -->
    <link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
        crossorigin=""></script>
```

Fügen sie dann noch als **letzten Teil im Body** des HTML Dokuments folgendes Fragment ein:

```HTML
<!-- Load JavaScripts
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./javascripts/geotagging.js"></script>
```

### 2.1.3 CSS erweitern

Die CSS Datei aus Aufgabe 1 muss auch angepasst werden, um die Kartendarstellung mit der Leaflet-API zu ermöglichen.

Fügen Sie folgende **neue Regel** in die CSS Datei ein:

```CSS
#map { 
   height: 500px;
 }
```



### 1. Teilaufgabe: Koordinaten in die Formulare eintragen

Das JavaScript enthält zunächst einige Klassen mit Hilfsfunktionen. Die Klasse `LocationHelper` erleichtert die Verwendung der HTML5 Geolocation API zur Bestimmung der Position. Die Funktion `findLocation` nimmt als Parameter eine *Callback Funktion* an, die bei Erfolg mit einem instanziierten LocationHelper Objekt 'zurückgerufen' wird. Das LocationHelper Objekt enthält dann die aktuellen Koordinaten als private Properties, die mit einer 'get'-Methode ausgelesen werden können. Beim Aufruf der Funktion muss die Callback Funktion übergeben werden.

Fügen sie eine Funktion `updateLocation` zum Skript hinzu, die folgendes tut:

- Auslesen der Position mit `findLocation`
- Im Erfolgsfall `latitude` und `longitude` Eingabefelder des Tagging-Formulars *und* des Discovery-Formulars (versteckte Eingabefelder) suchen und in deren `value`-Attribute Koordinaten schreiben.

Rufen sie die neue `updateLocation`-Funktion nach dem Laden des Dokuments automatisch auf.

### 2. Teilaufgabe: Position auf Karte darstellen

Wir wollen nun die gefundene Position auf einer Karte darstellen. Konkret werden wir zu diesem Zweck *Leaflet* verwenden, ein - für unsere Zwecke - kostenfreier Dienst um dynamische Karten anzuzeigen.

Die Klasse `MapManager` enthält einige Hilfsfunktionen zur Verwendung von Leaflet. Um eine Instanz zu erzeugen, wird der Konstruktor aufgerufen. Dann kann die Methode `initMap` verwendet werden, um die Karte mit der aktuellen Position zu initialisieren. Mit der Funktion `updateMarkers` werden die übergebenen GeoTags auf der Karte als Marker angezeigt. Beim Aufruf der Methode werden die zuvor vorhandenen Marker entfernt.

Ergänzen sie ihre `updateLocation`-Funktion wie folgt:

- Rufen sie die Funktionen `initMap` und `updateMarkers` mit den aktuellen Koordinaten auf. Daraufhin wird die Karte in Ihrer App angezeigt.
- Suchen sie im DOM das **Image Element** auf der Webseite.
- Löschen Sie sowohl das `<img>`-Element als auch das `<p>`-Element für die Beschriftung mithilfe des DOM (nicht in der HTML Datei). Dadurch wird der *Platzhalter* zur anfänglich Darstellung der Karte auf der Webseite wieder entfernt.

## Checkliste

Zur Übersicht folgen noch mal alle Anforderungen in kompakter Form als Checkliste.

### 1. Teilaufgabe: Koordinaten bestimmen

- [ ] Funktion `updateLocation` erstellen
  - [ ] Nach dem Laden automatisch aufrufen
  - [ ] Auslesen der Position mit `findLocation`
  - [ ] Koordinaten in die Formulare eintragen
    - [ ] `latitude` und `longitude` Felder
    - [ ] Koordinaten in `value`-Attribute schreiben
    - [ ] Auch versteckte Eingabefelder berücksichtigen

### 2. Teilaufgabe: Karte darstellen

- [ ] `updateLocation`-Funktion ergänzen
  - [ ] Funktionen `initMap` und `updateMarkers` aufrufen
  - [ ] `img` und `p`-Elemente mit DOM-Funktionen entfernen